﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LastFM : MonoBehaviour
{
    public LogData datalogger;    	
    public GameObject Artist;
    public GameObject Album;
   // public GameObject Track;
    public GameObject Text; 
    
    public string url = "http://ws.audioscrobbler.com/2.0/";

    IEnumerator Start ()
    {
        WWW www = new WWW(url);
        yield return www;

        JSONObject rawdata = new JSONObject(www.text);

        JSONObject toptracks = rawdata["toptracks"];
        //JSONObject track1 = toptracks["track"];

        //JSONObject trackDetails = track ["info"];
        Debug.Log(www.text);
        //Debug.Log(trackDetails.ToString());
        // Debug.Log("does this work?");

        Debug.Log(rawdata.str);
       // Debug.Log(toptracks.str);
       // Debug.Log(track1.str);
	
    //if (Track.ToString() == "song")
    {
      //  Track.SetActive(true);
    }
    if (Album.ToString() == "LP")
    {
    Album.SetActive(true);
    }
    if (Artist.ToString() == "musician")
    {
    Artist.SetActive(true);
    }
    if (Text.ToString() == "happy")
    {
    Text.SetActive(true);
    }

    }
}