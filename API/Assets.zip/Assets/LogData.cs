﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LogData : MonoBehaviour
{
    public void PrintData(float data)
    {
        Debug.Log("from datalog" + data.ToString());
    }

}
