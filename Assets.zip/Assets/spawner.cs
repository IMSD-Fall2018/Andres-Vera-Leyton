﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner : MonoBehaviour {
    public GameObject spawn;
    //public float initialDelay = 0;
    //public float repeatRate = 1f;
    //int numberSpawn = 1;
    public void SpawnObject(Vector3 spawnPosition){
        GameObject child = Instantiate(spawn, spawnPosition, Quaternion.identity);
    }

	// Use this for initialization
	void Start () {
        
	}
	

	void Update () {
      
	}
}
//void SpawnObject(){
   // if (numberSpawned <= 10)
   // {
       // Vector3 spawnPosition;
       // Vector3spawnOffset;
        //spawnOffset = new Vector3(Random.Range(-2f, 2f), Random.Range(-2f, 2f), 0);
        //spawnPostion=this.transfrom.position;
       // spawnPosition = this.transform.position + spawnOffset;

        //GameObject child = Instantiate(spawn), spawnPosition, Quaternion.identity);
        //child.name = "Rotator Clone" + numberSpawned;
        //child.GetComponent<Rotate>().rotateSpeed + Random.Range(-200f, 200f);
        //numberSpawned++;
   // }
   // }
//}